print("hello world from python\n\n")
print("i will show you some data")
myname = "kate"
age = 19
eyes = "brown"

print(f"hello, {myname}. you are {age} years old. you have {eyes} eyes.")